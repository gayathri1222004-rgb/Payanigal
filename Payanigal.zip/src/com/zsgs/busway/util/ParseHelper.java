package com.zsgs.busway.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ParseHelper {

    private static final String DATE_PATTERN      = "dd-MM-yyyy";
    private static final String DATETIME_PATTERN  = "dd-MM-yyyy HH:mm";
    private static final String TIME_PATTERN      = "HH:mm";
    private static final String EMPTY             = "-";

    private ParseHelper() {
    }

    /* ------------------------------------------------------------------ */
    /*  Parsing                                                             */
    /* ------------------------------------------------------------------ */

    public static Integer parsePositiveInt(String input) {
        if (input == null) return null;
        String trimmed = input.trim();
        if (trimmed.isEmpty()) return null;
        long result = 0L;
        for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            if (c < '0' || c > '9') return null;
            result = result * 10 + (c - '0');
            if (result > Integer.MAX_VALUE) return null;
        }
        return (int) result;
    }

    /** Parses "dd-MM-yyyy" and returns epoch millis, or null on failure. */
    public static Long parseDate(String input) {
        if (input == null || input.trim().isEmpty()) return null;
        SimpleDateFormat fmt = new SimpleDateFormat(DATE_PATTERN, Locale.ROOT);
        fmt.setLenient(false);
        try {
            return fmt.parse(input.trim()).getTime();
        } catch (ParseException e) {
            return null;
        }
    }

    /**
     * Parses "dd-MM-yyyy HH:mm" and returns epoch millis, or null on failure.
     * Accepts date-only "dd-MM-yyyy" as 00:00 of that day.
     */
    public static Long parseDateTime(String input) {
        if (input == null || input.trim().isEmpty()) return null;
        String trimmed = input.trim();
        SimpleDateFormat fmt;
        if (trimmed.length() == 10) {
            fmt = new SimpleDateFormat(DATE_PATTERN, Locale.ROOT);
        } else {
            fmt = new SimpleDateFormat(DATETIME_PATTERN, Locale.ROOT);
        }
        fmt.setLenient(false);
        try {
            return fmt.parse(trimmed).getTime();
        } catch (ParseException e) {
            return null;
        }
    }

    public static boolean isYes(String input) {
        if (input == null) return false;
        String t = input.trim();
        return !t.isEmpty() && (t.charAt(0) == 'Y' || t.charAt(0) == 'y');
    }

    public static int calculateAgeYears(long dobMillis) {
        Calendar dob = Calendar.getInstance();
        dob.setTimeInMillis(dobMillis);
        Calendar now = Calendar.getInstance();
        int age = now.get(Calendar.YEAR) - dob.get(Calendar.YEAR);
        if (now.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) age--;
        return age;
    }

    public static boolean isTodayOrFuture(long millis) {
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        return millis >= today.getTimeInMillis();
    }

    public static boolean isFutureDateTime(long millis) {
        return millis > System.currentTimeMillis();
    }

    /* ------------------------------------------------------------------ */
    /*  Formatting                                                          */
    /* ------------------------------------------------------------------ */

    public static String formatDate(Long millis) {
        if (millis == null) return EMPTY;
        return new SimpleDateFormat(DATE_PATTERN, Locale.ROOT).format(new Date(millis));
    }

    public static String formatTime(Long millis) {
        if (millis == null) return EMPTY;
        return new SimpleDateFormat(TIME_PATTERN, Locale.ROOT).format(new Date(millis));
    }

    public static String formatDateTime(Long millis) {
        if (millis == null) return EMPTY;
        return new SimpleDateFormat(DATETIME_PATTERN, Locale.ROOT).format(new Date(millis));
    }

    /** Returns "Xh Ym" duration between two epoch millis. */
    public static String formatDuration(long fromMillis, long toMillis) {
        long diff = toMillis - fromMillis;
        if (diff < 0) return EMPTY;
        long totalMinutes = diff / 60000;
        long hours   = totalMinutes / 60;
        long minutes = totalMinutes % 60;
        return hours + "h " + minutes + "m";
    }

    /** Formats a fare as "Rs. X,XXX". */
    public static String formatFare(double fare) {
        long l = Math.round(fare);
        StringBuilder sb = new StringBuilder(String.valueOf(l));
        sb.reverse();
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < sb.length(); i++) {
            if (i == 3 && sb.length() > 3) out.append(',');
            else if (i > 3 && (i - 3) % 2 == 0) out.append(',');
            out.append(sb.charAt(i));
        }
        return "Rs. " + out.reverse().toString();
    }
}
