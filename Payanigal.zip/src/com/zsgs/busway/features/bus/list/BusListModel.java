package com.zsgs.busway.features.bus.list;

import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.repository.BusWayDB;

import java.util.List;

class BusListModel {
    List<Bus> getAllBuses() { return BusWayDB.getInstance().getAllBuses(); }
}
