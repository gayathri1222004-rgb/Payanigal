package com.zsgs.busway.features.bus.list;

import com.zsgs.busway.data.dto.Bus;

import java.util.List;

public class BusListView {

    private final BusListModel model;

    public BusListView() {
        this.model = new BusListModel();
    }

    public void init() {
        System.out.println();
        System.out.println("=== All Buses ===");
        List<Bus> buses = model.getAllBuses();
        if (buses.isEmpty()) { System.out.println("No buses registered yet."); return; }

        System.out.printf("%-5s %-14s %-25s %-20s %-8s %s%n",
                "ID", "Bus Number", "Operator", "Type", "Seats", "Status");
        System.out.println("-".repeat(85));
        for (Bus b : buses) {
            System.out.printf("%-5d %-14s %-25s %-20s %-8d %s%n",
                    b.getId(),
                    b.getBusNumber(),
                    trunc(b.getOperatorName(), 24),
                    Bus.labelFor(b.getBusType()),
                    b.getTotalSeats(),
                    b.getStatus().name());
        }
        System.out.println("Total: " + buses.size() + " buses");
    }

    private String trunc(String s, int max) {
        if (s == null) return "-";
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
