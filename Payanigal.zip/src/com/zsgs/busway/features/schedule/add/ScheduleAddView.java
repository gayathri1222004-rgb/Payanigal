package com.zsgs.busway.features.schedule.add;

import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.util.ConsoleInput;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;
import java.util.Scanner;

public class ScheduleAddView {

    private final ScheduleAddModel model;
    private final Scanner          scanner;

    public ScheduleAddView() {
        this.model   = new ScheduleAddModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println();
        System.out.println("=== Add New Schedule ===");

        List<Bus>   buses  = model.getAllActiveBuses();
        List<Route> routes = model.getAllRoutes();

        if (buses.isEmpty())  { System.out.println("No buses available. Add a bus first."); return; }
        if (routes.isEmpty()) { System.out.println("No routes available. Add a route first."); return; }

        printBuses(buses);
        Long busId = pickBusId(buses);
        if (busId == null) return;

        printRoutes(routes);
        Long routeId = pickRouteId(routes);
        if (routeId == null) return;

        Long   departure = promptDateTime("Departure (dd-MM-yyyy HH:mm): ");
        Long   arrival   = promptArrival(departure);
        double fare      = promptFare();

        Bus   bus   = model.getBusById(busId);
        Route route = model.getRouteById(routeId);
        System.out.println();
        System.out.println("--- Schedule Summary ---");
        System.out.println("Bus     : " + (bus   != null ? bus.getOperatorName() + " [" + bus.getBusNumber() + "]" : "-"));
        System.out.println("Route   : " + (route != null ? route.getDisplay() : "-"));
        System.out.println("Departs : " + ParseHelper.formatDateTime(departure));
        System.out.println("Arrives : " + ParseHelper.formatDateTime(arrival));
        System.out.println("Duration: " + ParseHelper.formatDuration(departure, arrival));
        System.out.println("Fare    : " + ParseHelper.formatFare(fare) + " per seat");
        System.out.print("Add this schedule? (Y/N): ");
        if (!ParseHelper.isYes(scanner.nextLine())) { System.out.println("Cancelled."); return; }

        model.addSchedule(busId, routeId, departure, arrival, fare);
    }

    // ── Prompts ──────────────────────────────────────────────────────────

    private Long pickBusId(List<Bus> buses) {
        while (true) {
            System.out.print("Select bus number (or 0 to cancel): ");
            Integer n = ParseHelper.parsePositiveInt(scanner.nextLine());
            if (n == null)                  { System.out.println("  Error: Invalid choice."); continue; }
            if (n == 0)                     return null;
            if (n < 1 || n > buses.size())  { System.out.println("  Error: Enter between 1 and " + buses.size()); continue; }
            return buses.get(n - 1).getId();
        }
    }

    private Long pickRouteId(List<Route> routes) {
        while (true) {
            System.out.print("Select route number (or 0 to cancel): ");
            Integer n = ParseHelper.parsePositiveInt(scanner.nextLine());
            if (n == null)                   { System.out.println("  Error: Invalid choice."); continue; }
            if (n == 0)                      return null;
            if (n < 1 || n > routes.size())  { System.out.println("  Error: Enter between 1 and " + routes.size()); continue; }
            return routes.get(n - 1).getId();
        }
    }

    private Long promptDateTime(String label) {
        while (true) {
            System.out.print(label);
            Long t = model.parseFutureDateTime(scanner.nextLine());
            if (t != null) return t;
            System.out.println("  Error: Enter a future date-time (dd-MM-yyyy HH:mm).");
        }
    }

    private Long promptArrival(Long departure) {
        while (true) {
            System.out.print("Arrival  (dd-MM-yyyy HH:mm): ");
            Long arr = model.parseFutureDateTime(scanner.nextLine());
            if (arr == null) { System.out.println("  Error: Enter a future date-time."); continue; }
            String err = model.validateDepartureBefore(departure, arr);
            if (err != null) { System.out.println("  Error: " + err); continue; }
            return arr;
        }
    }

    private double promptFare() {
        while (true) {
            System.out.print("Fare per Seat (Rs.): ");
            String in  = scanner.nextLine();
            String err = model.validateFare(in);
            if (err == null) return Double.parseDouble(in.trim());
            System.out.println("  Error: " + err);
        }
    }

    // ── Display ──────────────────────────────────────────────────────────

    private void printBuses(List<Bus> buses) {
        System.out.println("Available Buses:");
        System.out.printf("  %-4s %-14s %-25s %-20s %s%n", "#", "Number", "Operator", "Type", "Seats");
        System.out.println("  " + "-".repeat(75));
        for (int i = 0; i < buses.size(); i++) {
            Bus b = buses.get(i);
            System.out.printf("  %-4d %-14s %-25s %-20s %d%n",
                    i + 1, b.getBusNumber(), trunc(b.getOperatorName(), 24),
                    Bus.labelFor(b.getBusType()), b.getTotalSeats());
        }
        System.out.println();
    }

    private void printRoutes(List<Route> routes) {
        System.out.println("Available Routes:");
        System.out.printf("  %-4s %-20s %-20s %s%n", "#", "Origin", "Destination", "Distance");
        System.out.println("  " + "-".repeat(60));
        for (int i = 0; i < routes.size(); i++) {
            Route r = routes.get(i);
            System.out.printf("  %-4d %-20s %-20s %d km%n",
                    i + 1, r.getOrigin(), r.getDestination(), r.getDistanceKm());
        }
        System.out.println();
    }

    private String trunc(String s, int max) {
        if (s == null) return "-";
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }

    // ── Callbacks ────────────────────────────────────────────────────────

    void onAddSuccess(Schedule sc) {
        System.out.println("Schedule added successfully! [ID: " + sc.getId() + "]");
    }

    void onAddFailed(String message) {
        System.out.println("Error: " + message);
    }
}
