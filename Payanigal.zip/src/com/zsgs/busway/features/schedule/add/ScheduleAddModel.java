package com.zsgs.busway.features.schedule.add;

import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;

class ScheduleAddModel {

    private final ScheduleAddView view;

    ScheduleAddModel(ScheduleAddView view) {
        this.view = view;
    }

    List<Bus>   getAllActiveBuses()  { return BusWayDB.getInstance().getActiveBuses(); }
    List<Route> getAllRoutes()       { return BusWayDB.getInstance().getAllRoutes(); }

    Bus   getBusById(Long id)   { return BusWayDB.getInstance().getBusById(id); }
    Route getRouteById(Long id) { return BusWayDB.getInstance().getRouteById(id); }

    Long parseFutureDateTime(String input) {
        Long millis = ParseHelper.parseDateTime(input);
        if (millis == null) return null;
        if (!ParseHelper.isFutureDateTime(millis)) return null;
        return millis;
    }

    String validateDepartureBefore(Long dep, Long arr) {
        if (dep == null || arr == null) return "Both times required.";
        if (!arr.equals(dep) && arr <= dep) return "Arrival must be after departure.";
        if (arr - dep < 30 * 60_000L)      return "Journey must be at least 30 minutes.";
        return null;
    }

    String validateFare(String input) {
        if (input == null || input.trim().isEmpty()) return "Fare cannot be empty.";
        try {
            double f = Double.parseDouble(input.trim());
            if (f <= 0)      return "Fare must be positive.";
            if (f > 10000)   return "Fare cannot exceed Rs. 10,000.";
            return null;
        } catch (NumberFormatException e) {
            return "Enter a valid number.";
        }
    }

    void addSchedule(Long busId, Long routeId, Long departure, Long arrival, double fare) {
        Schedule sc = new Schedule();
        sc.setBusId(busId);
        sc.setRouteId(routeId);
        sc.setDepartureTime(departure);
        sc.setArrivalTime(arrival);
        sc.setFarePerSeat(fare);
        sc.setStatus(Schedule.ScheduleStatus.SCHEDULED);

        Schedule saved = BusWayDB.getInstance().addSchedule(sc);
        if (saved == null) {
            view.onAddFailed("Failed to add schedule. Please try again.");
        } else {
            view.onAddSuccess(saved);
        }
    }
}
