package com.zsgs.busway.features.schedule.list;

import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;

public class ScheduleListView {

    private final ScheduleListModel model;

    public ScheduleListView() {
        this.model = new ScheduleListModel();
    }

    public void init() {
        System.out.println();
        System.out.println("=== All Schedules ===");
        List<Schedule> schedules = model.getAllSchedules();
        if (schedules.isEmpty()) { System.out.println("No schedules added yet."); return; }

        System.out.printf("%-4s %-22s %-22s %-14s %-14s %-10s %-10s %-8s %s%n",
                "ID", "Route", "Bus", "Departure", "Arrival", "Duration", "Fare", "Booked", "Status");
        System.out.println("-".repeat(125));

        for (Schedule sc : schedules) {
            Bus   bus   = BusWayDB.getInstance().getBusById(sc.getBusId());
            Route route = BusWayDB.getInstance().getRouteById(sc.getRouteId());
            int   booked = sc.getBookedSeats().size();
            int   total  = bus != null ? bus.getTotalSeats() : 0;
            System.out.printf("%-4d %-22s %-22s %-14s %-14s %-10s %-10s %-8s %s%n",
                    sc.getId(),
                    trunc(route != null ? route.getDisplay() : "-", 21),
                    trunc(bus   != null ? bus.getOperatorName() : "-", 21),
                    ParseHelper.formatDateTime(sc.getDepartureTime()),
                    ParseHelper.formatDateTime(sc.getArrivalTime()),
                    ParseHelper.formatDuration(sc.getDepartureTime(), sc.getArrivalTime()),
                    ParseHelper.formatFare(sc.getFarePerSeat()),
                    booked + "/" + total,
                    sc.getStatus().name());
        }
        System.out.println("Total: " + schedules.size() + " schedules");
    }

    private String trunc(String s, int max) {
        if (s == null) return "-";
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
