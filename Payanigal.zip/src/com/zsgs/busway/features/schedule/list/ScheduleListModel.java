package com.zsgs.busway.features.schedule.list;

import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.repository.BusWayDB;

import java.util.List;

class ScheduleListModel {
    List<Schedule> getAllSchedules() { return BusWayDB.getInstance().getAllSchedules(); }
}
