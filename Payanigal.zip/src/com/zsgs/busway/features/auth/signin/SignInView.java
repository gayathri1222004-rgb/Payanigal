package com.zsgs.busway.features.auth.signin;

import com.zsgs.busway.data.dto.LoginRequest;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.features.auth.signup.SignUpView;
import com.zsgs.busway.features.home.HomeView;
import com.zsgs.busway.util.ConsoleInput;

import java.util.Scanner;

public class SignInView {

    private final SignInModel model;
    private final Scanner     scanner;
    private boolean           authenticated = false;

    public SignInView() {
        this.model   = new SignInModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println();
        System.out.println("=== Sign In to BusWay ===");

        while (!authenticated) {
            promptAndAuthenticate();
            if (authenticated) return;
            if (!handleFailureMenu()) return;
        }
    }

    private void promptAndAuthenticate() {
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        LoginRequest request = new LoginRequest();
        request.setEmail(email == null ? null : email.trim());
        request.setPassword(password);
        model.authenticate(request);
    }

    private boolean handleFailureMenu() {
        while (true) {
            System.out.println();
            System.out.println("1. Retry");
            System.out.println("2. Sign Up");
            System.out.println("3. Return to main menu");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1": return true;
                case "2": new SignUpView().init(); return false;
                case "3": return false;
                default:  System.out.println("Invalid option.");
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Callbacks                                                           */
    /* ------------------------------------------------------------------ */

    void onSignInSuccess(User user) {
        authenticated = true;
        System.out.println();
        System.out.println("Welcome, " + user.getName() + "!");
        new HomeView(user).init();
    }

    void onSignInFailed(String message) {
        System.out.println("Error: " + message);
    }
}
