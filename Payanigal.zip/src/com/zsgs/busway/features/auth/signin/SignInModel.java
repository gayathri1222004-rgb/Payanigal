package com.zsgs.busway.features.auth.signin;

import com.zsgs.busway.data.dto.LoginRequest;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.data.repository.BusWayDB;

import java.util.regex.Pattern;

class SignInModel {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}$");

    private final SignInView view;

    SignInModel(SignInView view) {
        this.view = view;
    }

    String validateEmail(String email) {
        if (email == null || email.trim().isEmpty()) return "Email cannot be empty.";
        if (!EMAIL_PATTERN.matcher(email.trim()).matches()) return "Enter a valid email address.";
        return null;
    }

    String validatePassword(String password) {
        if (password == null || password.isEmpty()) return "Password cannot be empty.";
        return null;
    }

    void authenticate(LoginRequest request) {
        if (request == null) { view.onSignInFailed("Invalid credentials."); return; }

        String emailErr = validateEmail(request.getEmail());
        if (emailErr != null) { view.onSignInFailed(emailErr); return; }

        String passErr = validatePassword(request.getPassword());
        if (passErr != null) { view.onSignInFailed(passErr); return; }

        User user = BusWayDB.getInstance().authenticate(
                request.getEmail().trim().toLowerCase(),
                request.getPassword());

        if (user == null) { view.onSignInFailed("Invalid email or password."); return; }

        if (user.getStatus() == User.Status.INACTIVE) {
            view.onSignInFailed("Your account is inactive. Please contact support.");
            return;
        }
        view.onSignInSuccess(user);
    }
}
