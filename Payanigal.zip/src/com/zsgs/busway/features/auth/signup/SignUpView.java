package com.zsgs.busway.features.auth.signup;

import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.features.auth.signin.SignInView;
import com.zsgs.busway.util.ConsoleInput;

import java.util.Scanner;

public class SignUpView {

    private final SignUpModel model;
    private final Scanner     scanner;

    public SignUpView() {
        this.model   = new SignUpModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println();
        System.out.println("=== Create Your BusWay Account ===");

        String name     = promptName();
        String email    = promptEmail();
        String password = promptPassword();
        String mobile   = promptMobile();
        Long   dob      = promptDob();

        model.register(name, email, password, mobile, dob);
    }

    /* ------------------------------------------------------------------ */
    /*  Prompts                                                             */
    /* ------------------------------------------------------------------ */

    private String promptName() {
        while (true) {
            System.out.print("Full Name: ");
            String input = scanner.nextLine();
            String error = model.validateName(input);
            if (error == null) return input.trim();
            System.out.println("  Error: " + error);
        }
    }

    private String promptEmail() {
        while (true) {
            System.out.print("Email: ");
            String input = scanner.nextLine();
            String error = model.validateEmail(input);
            if (error == null) return input.trim();
            System.out.println("  Error: " + error);
        }
    }

    private String promptPassword() {
        while (true) {
            System.out.print("Password (min 8 chars, letters + digits): ");
            String input = scanner.nextLine();
            String error = model.validatePassword(input);
            if (error != null) { System.out.println("  Error: " + error); continue; }
            System.out.print("Confirm Password: ");
            String confirm = scanner.nextLine();
            String cError  = model.validateConfirmPassword(input, confirm);
            if (cError != null) { System.out.println("  Error: " + cError); continue; }
            return input;
        }
    }

    private String promptMobile() {
        while (true) {
            System.out.print("Mobile Number (10 digits): ");
            String input = scanner.nextLine();
            String error = model.validateMobile(input);
            if (error == null) return input.trim();
            System.out.println("  Error: " + error);
        }
    }

    private Long promptDob() {
        while (true) {
            System.out.print("Date of Birth (dd-MM-yyyy): ");
            String input = scanner.nextLine();
            Long   dob   = model.parseDob(input);
            if (dob != null) return dob;
            System.out.println("  Error: Enter a valid date (minimum age 18 years).");
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Callbacks                                                           */
    /* ------------------------------------------------------------------ */

    void onRegistrationSuccess(User user) {
        System.out.println();
        System.out.println("Account created successfully!");
        System.out.println("Your User ID: " + user.getUserId());
        System.out.println("Please sign in to continue.");
        new SignInView().init();
    }

    void onRegistrationFailed(String message) {
        System.out.println("Error: " + message);
    }
}
