package com.zsgs.busway.features.home;

import com.zsgs.busway.data.dto.User;

class HomeModel {

    private final HomeView view;

    HomeModel(HomeView view) {
        this.view = view;
    }

    void init(User user) {
        if (user == null || user.getRole() == null) {
            view.showError("Unable to determine your role. Please contact support.");
            return;
        }
        if (user.getRole() == User.Role.ADMIN) {
            view.showAdminMenu();
        } else {
            view.showPassengerMenu();
        }
    }
}
