package com.zsgs.busway.features.home;

import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.features.booking.cancel.BookingCancelView;
import com.zsgs.busway.features.booking.create.BookingCreateView;
import com.zsgs.busway.features.booking.detail.BookingDetailView;
import com.zsgs.busway.features.booking.list.BookingListView;
import com.zsgs.busway.features.booking.search.ScheduleSearchView;
import com.zsgs.busway.features.bus.add.BusAddView;
import com.zsgs.busway.features.bus.list.BusListView;
import com.zsgs.busway.features.notification.NotificationView;
import com.zsgs.busway.features.report.ReportView;
import com.zsgs.busway.features.route.add.RouteAddView;
import com.zsgs.busway.features.route.list.RouteListView;
import com.zsgs.busway.features.schedule.add.ScheduleAddView;
import com.zsgs.busway.features.schedule.list.ScheduleListView;
import com.zsgs.busway.util.ConsoleInput;

import java.util.Scanner;

public class HomeView {

    private final HomeModel model;
    private final User      user;
    private final Scanner   scanner;

    public HomeView(User user) {
        this.model   = new HomeModel(this);
        this.user    = user;
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        model.init(user);
    }

    /* ------------------------------------------------------------------ */
    /*  Passenger Menu                                                      */
    /* ------------------------------------------------------------------ */

    void showPassengerMenu() {
        while (true) {
            long unread = BusWayDB.getInstance().getUnreadNotificationCount(user.getId());
            String notifLabel = unread > 0 ? "Notifications  [" + unread + " new]" : "Notifications";

            System.out.println();
            System.out.println("--- Passenger Menu (" + user.getName() + ") ---");
            System.out.println("1.  Search Buses");
            System.out.println("2.  Book a Ticket");
            System.out.println("3.  My Bookings");
            System.out.println("4.  View Booking Details / PNR Status");
            System.out.println("5.  Cancel Booking");
            System.out.println("6.  " + notifLabel);
            System.out.println("7.  Sign Out");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1": new ScheduleSearchView(user).init();  break;
                case "2": new BookingCreateView(user).init();   break;
                case "3": new BookingListView(user).init();     break;
                case "4": new BookingDetailView(user).init();   break;
                case "5": new BookingCancelView(user).init();   break;
                case "6": new NotificationView(user).init();    break;
                case "7":
                    System.out.println("You have been signed out. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Admin Menu                                                          */
    /* ------------------------------------------------------------------ */

    void showAdminMenu() {
        while (true) {
            System.out.println();
            System.out.println("--- Admin Menu (" + user.getName() + ") ---");
            System.out.println("1.  Add Bus");
            System.out.println("2.  View All Buses");
            System.out.println("3.  Add Route");
            System.out.println("4.  View All Routes");
            System.out.println("5.  Add Schedule");
            System.out.println("6.  View All Schedules");
            System.out.println("7.  View All Bookings");
            System.out.println("8.  View Reports");
            System.out.println("9.  Sign Out");
            System.out.print("Choose an option: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1": new BusAddView().init();          break;
                case "2": new BusListView().init();         break;
                case "3": new RouteAddView().init();        break;
                case "4": new RouteListView().init();       break;
                case "5": new ScheduleAddView().init();     break;
                case "6": new ScheduleListView().init();    break;
                case "7": new BookingListView(user).initAdmin(); break;
                case "8": new ReportView().init();          break;
                case "9":
                    System.out.println("You have been signed out. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    void showError(String message) {
        System.out.println("Error: " + message);
    }
}
