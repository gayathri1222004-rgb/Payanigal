package com.zsgs.busway.features.booking.create;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ConsoleInput;
import com.zsgs.busway.util.ParseHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookingCreateView {

    private final BookingCreateModel model;
    private final User               currentUser;
    private final Scanner            scanner;

    public BookingCreateView(User currentUser) {
        this.model       = new BookingCreateModel(this);
        this.currentUser = currentUser;
        this.scanner     = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println();
        System.out.println("=== Book a Ticket ===");

        List<String> cities = model.getAllCities();
        if (cities.isEmpty()) { System.out.println("No routes available yet."); return; }

        System.out.println("Available cities: " + String.join(", ", cities));
        System.out.println();

        // Step 1 – pick route & date
        String origin      = promptCity("From (Origin): ");
        String destination = promptDestination(origin);
        Long   travelDate  = promptTravelDate();

        // Step 2 – show schedules
        List<Schedule> schedules = model.searchSchedules(origin, destination, travelDate);
        if (schedules.isEmpty()) {
            System.out.println("No buses found for " + origin + " -> " + destination
                    + " on " + ParseHelper.formatDate(travelDate) + ".");
            return;
        }
        printSchedules(schedules);
        Schedule chosen = pickSchedule(schedules);
        if (chosen == null) return;

        // Step 3 – seat count
        Bus bus   = BusWayDB.getInstance().getBusById(chosen.getBusId());
        int avail = chosen.availableSeats(bus.getTotalSeats());
        int seats = promptSeatCount(avail);

        // Step 4 – seat selection
        List<Integer> available = model.getAvailableSeats(chosen);
        printSeatMap(bus, chosen);
        List<Integer> chosenSeats = pickSeats(available, seats);

        // Step 5 – confirm
        double fare = model.calculateFare(chosen, seats);
        System.out.println();
        System.out.println("--- Booking Summary ---");
        Route route = BusWayDB.getInstance().getRouteById(chosen.getRouteId());
        System.out.println("Route     : " + (route != null ? route.getDisplay() : "-"));
        System.out.println("Date      : " + ParseHelper.formatDate(chosen.getDepartureTime()));
        System.out.println("Departure : " + ParseHelper.formatTime(chosen.getDepartureTime()));
        System.out.println("Arrival   : " + ParseHelper.formatTime(chosen.getArrivalTime()));
        System.out.println("Bus       : " + bus.getOperatorName() + " [" + Bus.labelFor(bus.getBusType()) + "]");
        System.out.println("Seats     : " + chosenSeats);
        System.out.println("Total Fare: " + ParseHelper.formatFare(fare));
        System.out.print("Confirm booking? (Y/N): ");
        if (!ParseHelper.isYes(scanner.nextLine())) { System.out.println("Booking cancelled."); return; }

        model.confirmBooking(currentUser, chosen, chosenSeats);
    }

    // ── Prompts ──────────────────────────────────────────────────────────

    private String promptCity(String label) {
        while (true) {
            System.out.print(label);
            String in  = scanner.nextLine();
            String err = model.validateCity(in);
            if (err == null) return in.trim();
            System.out.println("  Error: " + err);
        }
    }

    private String promptDestination(String origin) {
        while (true) {
            System.out.print("To (Destination): ");
            String in = scanner.nextLine();
            if (model.validateCity(in) != null)         { System.out.println("  Error: " + model.validateCity(in)); continue; }
            if (model.validateSameCity(origin, in) != null) { System.out.println("  Error: " + model.validateSameCity(origin, in)); continue; }
            return in.trim();
        }
    }

    private Long promptTravelDate() {
        while (true) {
            System.out.print("Travel Date (dd-MM-yyyy): ");
            Long d = model.parseTravelDate(scanner.nextLine());
            if (d != null) return d;
            System.out.println("  Error: Enter a valid date (today or future).");
        }
    }

    private int promptSeatCount(int available) {
        while (true) {
            System.out.print("Number of seats (available: " + available + "): ");
            String err = model.validateSeatCount(scanner.nextLine(), available);
            if (err == null) {
                // re-read last input — re-prompt to capture value
                System.out.print("Number of seats (available: " + available + "): ");
                String in2 = scanner.nextLine();
                String e2  = model.validateSeatCount(in2, available);
                if (e2 == null) return Integer.parseInt(in2.trim());
                System.out.println("  Error: " + e2);
            } else {
                System.out.println("  Error: " + err);
            }
        }
    }

    private List<Integer> pickSeats(List<Integer> available, int count) {
        List<Integer> picked = new ArrayList<>();
        while (picked.size() < count) {
            System.out.print("Select seat " + (picked.size() + 1) + " of " + count + ": ");
            String in  = scanner.nextLine().trim();
            String err = model.validateSeatChoice(in, available);
            if (err != null) { System.out.println("  Error: " + err); continue; }
            int seat = Integer.parseInt(in);
            if (picked.contains(seat)) { System.out.println("  Error: Seat already selected."); continue; }
            picked.add(seat);
            available.remove(Integer.valueOf(seat));
        }
        return picked;
    }

    private Schedule pickSchedule(List<Schedule> schedules) {
        while (true) {
            System.out.print("Select bus number (1-" + schedules.size() + ") or 0 to cancel: ");
            Integer n = ParseHelper.parsePositiveInt(scanner.nextLine());
            if (n == null)                              { System.out.println("  Error: Invalid choice."); continue; }
            if (n == 0)                                 { return null; }
            if (n < 1 || n > schedules.size())          { System.out.println("  Error: Enter between 1 and " + schedules.size()); continue; }
            Schedule sc  = schedules.get(n - 1);
            Bus      bus = BusWayDB.getInstance().getBusById(sc.getBusId());
            if (bus != null && sc.availableSeats(bus.getTotalSeats()) == 0) {
                System.out.println("  Error: No seats available on that bus.");
                continue;
            }
            return sc;
        }
    }

    // ── Display ──────────────────────────────────────────────────────────

    private void printSchedules(List<Schedule> schedules) {
        System.out.println();
        System.out.printf("%-4s %-25s %-18s %-10s %-10s %-10s %-10s %s%n",
                "#", "Operator", "Type", "Departs", "Arrives", "Duration", "Fare/Seat", "Avail");
        System.out.println("-".repeat(105));
        for (int i = 0; i < schedules.size(); i++) {
            Schedule sc  = schedules.get(i);
            Bus      bus = BusWayDB.getInstance().getBusById(sc.getBusId());
            if (bus == null) continue;
            System.out.printf("%-4d %-25s %-18s %-10s %-10s %-10s %-10s %d%n",
                    i + 1,
                    trunc(bus.getOperatorName(), 24),
                    Bus.labelFor(bus.getBusType()),
                    ParseHelper.formatTime(sc.getDepartureTime()),
                    ParseHelper.formatTime(sc.getArrivalTime()),
                    ParseHelper.formatDuration(sc.getDepartureTime(), sc.getArrivalTime()),
                    ParseHelper.formatFare(sc.getFarePerSeat()),
                    sc.availableSeats(bus.getTotalSeats()));
        }
        System.out.println();
    }

    private void printSeatMap(Bus bus, Schedule schedule) {
        System.out.println();
        System.out.println("Seat Map ([A]=Available  [X]=Booked)");
        int cols  = (bus.getBusType() == Bus.BusType.AC_SLEEPER || bus.getBusType() == Bus.BusType.NON_AC_SLEEPER) ? 4 : 5;
        int total = bus.getTotalSeats();
        for (int i = 1; i <= total; i++) {
            String marker = schedule.isSeatAvailable(i) ? String.format("[%2d]", i) : "[ X]";
            System.out.print(marker + " ");
            if (i % cols == 0) System.out.println();
        }
        if (total % cols != 0) System.out.println();
        System.out.println();
    }

    private String trunc(String s, int max) {
        if (s == null) return "-";
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }

    // ── Callbacks ────────────────────────────────────────────────────────

    public void onBookingSuccess(Booking booking) {
        System.out.println();
        System.out.println("============================================");
        System.out.println("  BOOKING CONFIRMED!");
        System.out.println("============================================");
        System.out.println("  PNR       : " + booking.getPnr());
        System.out.println("  Seats     : " + booking.getSeats());
        System.out.println("  Total Fare: " + ParseHelper.formatFare(booking.getTotalFare()));
        System.out.println("  Booked At : " + ParseHelper.formatDateTime(booking.getBookedAt()));
        System.out.println("============================================");
        System.out.println("Please carry this PNR for your journey.");
    }

    public void onBookingFailed(String message) {
        System.out.println("Error: " + message);
    }
}
