package com.zsgs.busway.features.booking.create;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Notification;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ParseHelper;

import java.util.ArrayList;
import java.util.List;

class BookingCreateModel {

    private static final int MAX_SEATS_PER_BOOKING = 6;

    private final BookingCreateView view;

    BookingCreateModel(BookingCreateView view) {
        this.view = view;
    }

    List<String> getAllCities() {
        return BusWayDB.getInstance().getAllCities();
    }

    String validateCity(String city) {
        if (city == null || city.trim().isEmpty()) return "City cannot be empty.";
        return null;
    }

    String validateSameCity(String o, String d) {
        if (o != null && d != null && o.trim().equalsIgnoreCase(d.trim()))
            return "Origin and destination cannot be the same.";
        return null;
    }

    Long parseTravelDate(String input) {
        Long millis = ParseHelper.parseDate(input);
        if (millis == null) return null;
        if (!ParseHelper.isTodayOrFuture(millis)) return null;
        return millis;
    }

    List<Schedule> searchSchedules(String origin, String destination, long travelDate) {
        return BusWayDB.getInstance().searchSchedules(origin, destination, travelDate);
    }

    String validateSeatCount(String input, int available) {
        if (input == null || input.trim().isEmpty()) return "Please enter a number.";
        Integer n = ParseHelper.parsePositiveInt(input);
        if (n == null || n <= 0)               return "Enter a valid positive number.";
        if (n > MAX_SEATS_PER_BOOKING)         return "Maximum " + MAX_SEATS_PER_BOOKING + " seats per booking.";
        if (n > available)                     return "Only " + available + " seats available.";
        return null;
    }

    /** Returns list of available seat numbers for a schedule. */
    List<Integer> getAvailableSeats(Schedule schedule) {
        Bus bus = BusWayDB.getInstance().getBusById(schedule.getBusId());
        if (bus == null) return new ArrayList<>();
        List<Integer> available = new ArrayList<>();
        for (int i = 1; i <= bus.getTotalSeats(); i++) {
            if (schedule.isSeatAvailable(i)) available.add(i);
        }
        return available;
    }

    String validateSeatChoice(String input, List<Integer> available) {
        Integer n = ParseHelper.parsePositiveInt(input);
        if (n == null) return "Enter a valid seat number.";
        if (!available.contains(n)) return "Seat " + n + " is not available.";
        return null;
    }

    double calculateFare(Schedule schedule, int seats) {
        return schedule.getFarePerSeat() * seats;
    }

    void confirmBooking(User user, Schedule schedule, List<Integer> seats) {
        double totalFare = calculateFare(schedule, seats.size());

        Booking booking = new Booking();
        booking.setUserId(user.getId());
        booking.setScheduleId(schedule.getId());
        booking.setSeats(new ArrayList<>(seats));
        booking.setPassengerCount(seats.size());
        booking.setTotalFare(totalFare);
        booking.setStatus(Booking.BookingStatus.CONFIRMED);

        Booking saved = BusWayDB.getInstance().addBooking(booking);
        if (saved == null) {
            view.onBookingFailed("Booking could not be completed. Please try again.");
            return;
        }

        // Notification
        Notification notif = new Notification();
        notif.setUserId(user.getId());
        notif.setBookingId(saved.getId());
        notif.setType(Notification.NotificationType.BOOKING_CONFIRMED);
        notif.setMessage("Booking confirmed! PNR: " + saved.getPnr()
                + " | Seats: " + seats + " | Fare: " + ParseHelper.formatFare(totalFare));
        BusWayDB.getInstance().addNotification(notif);

        view.onBookingSuccess(saved);
    }
}
