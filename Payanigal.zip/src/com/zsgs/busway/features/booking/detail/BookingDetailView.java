package com.zsgs.busway.features.booking.detail;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ConsoleInput;
import com.zsgs.busway.util.ParseHelper;

import java.util.Scanner;

public class BookingDetailView {

    private final BookingDetailModel model;
    private final User               currentUser;
    private final Scanner            scanner;

    public BookingDetailView(User currentUser) {
        this.model       = new BookingDetailModel();
        this.currentUser = currentUser;
        this.scanner     = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println();
        System.out.println("=== PNR / Booking Status ===");

        while (true) {
            System.out.print("Enter PNR (or 0 to go back): ");
            String input = scanner.nextLine().trim();
            if ("0".equals(input)) return;

            String err = model.validatePnr(input);
            if (err != null) { System.out.println("  Error: " + err); continue; }

            Booking booking = model.findByPnr(input);
            if (booking == null) {
                System.out.println("  No booking found for PNR: " + input.toUpperCase());
                continue;
            }
            printDetail(booking);
            return;
        }
    }

    private void printDetail(Booking booking) {
        Schedule sc  = BusWayDB.getInstance().getScheduleById(booking.getScheduleId());
        Bus      bus = sc != null ? BusWayDB.getInstance().getBusById(sc.getBusId()) : null;
        Route    rt  = sc != null ? BusWayDB.getInstance().getRouteById(sc.getRouteId()) : null;
        User     u   = BusWayDB.getInstance().getUserById(booking.getUserId());

        System.out.println();
        System.out.println("============================================");
        System.out.println("  BOOKING DETAILS");
        System.out.println("============================================");
        System.out.println("  PNR            : " + booking.getPnr());
        System.out.println("  Status         : " + booking.getStatus().name());
        System.out.println("  Passenger      : " + (u != null ? u.getName() : "-"));
        System.out.println("  Route          : " + (rt  != null ? rt.getDisplay() : "-"));
        System.out.println("  Date           : " + (sc  != null ? ParseHelper.formatDate(sc.getDepartureTime()) : "-"));
        System.out.println("  Departure      : " + (sc  != null ? ParseHelper.formatTime(sc.getDepartureTime()) : "-"));
        System.out.println("  Arrival        : " + (sc  != null ? ParseHelper.formatTime(sc.getArrivalTime())   : "-"));
        System.out.println("  Duration       : " + (sc  != null ? ParseHelper.formatDuration(sc.getDepartureTime(), sc.getArrivalTime()) : "-"));
        System.out.println("  Bus            : " + (bus != null ? bus.getOperatorName() + " [" + Bus.labelFor(bus.getBusType()) + "]" : "-"));
        System.out.println("  Bus Number     : " + (bus != null ? bus.getBusNumber() : "-"));
        System.out.println("  Seats          : " + booking.getSeats());
        System.out.println("  Total Fare     : " + ParseHelper.formatFare(booking.getTotalFare()));
        System.out.println("  Booked At      : " + ParseHelper.formatDateTime(booking.getBookedAt()));
        if (booking.getStatus() == Booking.BookingStatus.CANCELLED) {
            System.out.println("  Cancelled At   : " + ParseHelper.formatDateTime(booking.getCancelledAt()));
            if (booking.getCancellationReason() != null)
                System.out.println("  Cancel Reason  : " + booking.getCancellationReason());
        }
        System.out.println("============================================");
    }
}
