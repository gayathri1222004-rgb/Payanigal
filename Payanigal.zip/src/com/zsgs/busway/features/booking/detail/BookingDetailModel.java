package com.zsgs.busway.features.booking.detail;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.repository.BusWayDB;

class BookingDetailModel {

    Booking findByPnr(String pnr) {
        if (pnr == null || pnr.trim().isEmpty()) return null;
        return BusWayDB.getInstance().getBookingByPnr(pnr.trim().toUpperCase());
    }

    String validatePnr(String pnr) {
        if (pnr == null || pnr.trim().isEmpty()) return "PNR cannot be empty.";
        if (!pnr.trim().toUpperCase().startsWith("BW")) return "Invalid PNR format (should start with BW).";
        return null;
    }
}
