package com.zsgs.busway.features.booking.list;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.repository.BusWayDB;

import java.util.List;

class BookingListModel {

    List<Booking> getBookingsForUser(Long userId) {
        return BusWayDB.getInstance().getBookingsByUser(userId);
    }

    List<Booking> getAllBookings() {
        return BusWayDB.getInstance().getAllBookings();
    }
}
