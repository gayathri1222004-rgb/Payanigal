package com.zsgs.busway.features.booking.list;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;

public class BookingListView {

    private final BookingListModel model;
    private final User             currentUser;

    public BookingListView(User currentUser) {
        this.model       = new BookingListModel();
        this.currentUser = currentUser;
    }

    public void init() {
        System.out.println();
        System.out.println("=== My Bookings ===");
        List<Booking> bookings = model.getBookingsForUser(currentUser.getId());
        if (bookings.isEmpty()) {
            System.out.println("You have no bookings yet.");
            return;
        }
        printTable(bookings, false);
    }

    public void initAdmin() {
        System.out.println();
        System.out.println("=== All Bookings ===");
        List<Booking> bookings = model.getAllBookings();
        if (bookings.isEmpty()) {
            System.out.println("No bookings in the system yet.");
            return;
        }
        printTable(bookings, true);
    }

    private void printTable(List<Booking> bookings, boolean showUser) {
        System.out.printf("%-14s %-22s %-12s %-10s %-12s %-12s %s%n",
                "PNR", "Route", "Date", "Seats", "Fare", "Status",
                showUser ? "Passenger" : "");
        System.out.println("-".repeat(showUser ? 110 : 90));

        for (Booking b : bookings) {
            Schedule sc    = BusWayDB.getInstance().getScheduleById(b.getScheduleId());
            String   route = "-";
            String   date  = "-";
            if (sc != null) {
                Route r = BusWayDB.getInstance().getRouteById(sc.getRouteId());
                if (r != null) route = r.getDisplay();
                date = ParseHelper.formatDate(sc.getDepartureTime());
            }
            String userCol = "";
            if (showUser) {
                User u = BusWayDB.getInstance().getUserById(b.getUserId());
                userCol = u != null ? u.getName() : "-";
            }
            System.out.printf("%-14s %-22s %-12s %-10s %-12s %-12s %s%n",
                    b.getPnr(),
                    trunc(route, 21),
                    date,
                    b.getSeats().toString(),
                    ParseHelper.formatFare(b.getTotalFare()),
                    b.getStatus().name(),
                    userCol);
        }
    }

    private String trunc(String s, int max) {
        if (s == null) return "-";
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
