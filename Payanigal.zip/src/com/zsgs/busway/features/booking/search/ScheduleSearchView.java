package com.zsgs.busway.features.booking.search;

import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ConsoleInput;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;
import java.util.Scanner;

public class ScheduleSearchView {

    private final ScheduleSearchModel model;
    private final Scanner             scanner;
    private final User                currentUser;

    public ScheduleSearchView(User currentUser) {
        this.model       = new ScheduleSearchModel(this);
        this.scanner     = ConsoleInput.getScanner();
        this.currentUser = currentUser;
    }

    public void init() {
        System.out.println();
        System.out.println("=== Search Buses ===");

        List<String> cities = model.getAllCities();
        if (cities.isEmpty()) {
            System.out.println("No routes are available yet.");
            return;
        }

        System.out.println("Available cities: " + String.join(", ", cities));
        System.out.println();

        String origin      = promptCity("From (Origin City): ");
        String destination = promptDestination(origin);
        Long   travelDate  = promptTravelDate();

        List<Schedule> results = model.search(origin, destination, travelDate);

        System.out.println();
        if (results.isEmpty()) {
            System.out.println("No buses available for " + origin + " -> " + destination
                    + " on " + ParseHelper.formatDate(travelDate) + ".");
            return;
        }

        printResults(results, origin, destination);
    }

    /* ------------------------------------------------------------------ */
    /*  Prompts                                                             */
    /* ------------------------------------------------------------------ */

    private String promptCity(String label) {
        while (true) {
            System.out.print(label);
            String input = scanner.nextLine();
            String error = model.validateCity(input);
            if (error == null) return input.trim();
            System.out.println("  Error: " + error);
        }
    }

    private String promptDestination(String origin) {
        while (true) {
            System.out.print("To (Destination City): ");
            String input = scanner.nextLine();
            String cityErr = model.validateCity(input);
            if (cityErr != null) { System.out.println("  Error: " + cityErr); continue; }
            String sameErr = model.validateSameCity(origin, input);
            if (sameErr != null) { System.out.println("  Error: " + sameErr); continue; }
            return input.trim();
        }
    }

    private Long promptTravelDate() {
        while (true) {
            System.out.print("Travel Date (dd-MM-yyyy): ");
            Long date = model.parseTravelDate(scanner.nextLine());
            if (date != null) return date;
            System.out.println("  Error: Enter a valid date (today or future).");
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Display                                                             */
    /* ------------------------------------------------------------------ */

    private void printResults(List<Schedule> schedules, String origin, String destination) {
        System.out.println("Buses available for " + origin + " -> " + destination + ":");
        System.out.println();
        System.out.printf("%-4s %-25s %-20s %-12s %-12s %-10s %-10s %s%n",
                "#", "Operator", "Bus Type", "Departure", "Arrival", "Duration", "Fare/Seat", "Seats Left");
        System.out.println("-".repeat(110));

        for (int i = 0; i < schedules.size(); i++) {
            Schedule sc  = schedules.get(i);
            Bus      bus = BusWayDB.getInstance().getBusById(sc.getBusId());
            if (bus == null) continue;

            int  avail    = sc.availableSeats(bus.getTotalSeats());
            String duration = ParseHelper.formatDuration(sc.getDepartureTime(), sc.getArrivalTime());

            System.out.printf("%-4d %-25s %-20s %-12s %-12s %-10s %-10s %d%n",
                    (i + 1),
                    truncate(bus.getOperatorName(), 24),
                    Bus.labelFor(bus.getBusType()),
                    ParseHelper.formatTime(sc.getDepartureTime()),
                    ParseHelper.formatTime(sc.getArrivalTime()),
                    duration,
                    ParseHelper.formatFare(sc.getFarePerSeat()),
                    avail);
        }
    }

    private String truncate(String s, int max) {
        if (s == null) return "-";
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
