package com.zsgs.busway.features.booking.search;

import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;

class ScheduleSearchModel {

    private final ScheduleSearchView view;

    ScheduleSearchModel(ScheduleSearchView view) {
        this.view = view;
    }

    List<String> getAllCities() {
        return BusWayDB.getInstance().getAllCities();
    }

    String validateCity(String city) {
        if (city == null || city.trim().isEmpty()) return "City cannot be empty.";
        return null;
    }

    String validateSameCity(String origin, String destination) {
        if (origin == null || destination == null) return null;
        if (origin.trim().equalsIgnoreCase(destination.trim()))
            return "Origin and destination cannot be the same.";
        return null;
    }

    Long parseTravelDate(String input) {
        Long millis = ParseHelper.parseDate(input);
        if (millis == null) return null;
        if (!ParseHelper.isTodayOrFuture(millis)) return null;
        return millis;
    }

    List<Schedule> search(String origin, String destination, long travelDate) {
        return BusWayDB.getInstance().searchSchedules(origin, destination, travelDate);
    }
}
