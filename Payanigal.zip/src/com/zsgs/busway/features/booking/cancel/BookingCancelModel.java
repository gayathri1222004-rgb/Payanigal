package com.zsgs.busway.features.booking.cancel;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.dto.Notification;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;

class BookingCancelModel {

    private final BookingCancelView view;

    BookingCancelModel(BookingCancelView view) {
        this.view = view;
    }

    List<Booking> getActiveBookingsForUser(Long userId) {
        List<Booking> all    = BusWayDB.getInstance().getBookingsByUser(userId);
        List<Booking> active = new java.util.ArrayList<>();
        for (Booking b : all) {
            if (b.getStatus() == Booking.BookingStatus.CONFIRMED) {
                Schedule sc = BusWayDB.getInstance().getScheduleById(b.getScheduleId());
                if (sc != null && ParseHelper.isFutureDateTime(sc.getDepartureTime())) {
                    active.add(b);
                }
            }
        }
        return active;
    }

    String validateReason(String reason) {
        if (reason == null || reason.trim().isEmpty()) return "Please provide a cancellation reason.";
        if (reason.trim().length() < 5) return "Reason must be at least 5 characters.";
        return null;
    }

    void cancel(Booking booking, String reason, Long userId) {
        booking.setCancellationReason(reason.trim());
        boolean ok = BusWayDB.getInstance().cancelBooking(booking.getId());
        if (!ok) { view.onCancelFailed("Cancellation failed. Please try again."); return; }

        // Refund notification
        Notification notif = new Notification();
        notif.setUserId(userId);
        notif.setBookingId(booking.getId());
        notif.setType(Notification.NotificationType.BOOKING_CANCELLED);
        notif.setMessage("Booking " + booking.getPnr() + " cancelled. "
                + "Refund of " + ParseHelper.formatFare(booking.getTotalFare()) + " will be processed in 5-7 business days.");
        BusWayDB.getInstance().addNotification(notif);

        view.onCancelSuccess(booking);
    }
}
