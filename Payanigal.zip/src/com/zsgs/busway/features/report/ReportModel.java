package com.zsgs.busway.features.report;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.data.repository.BusWayDB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ReportModel {

    // ── Summary counts ────────────────────────────────────────────────

    int totalUsers()     { return BusWayDB.getInstance().getAllUsers().size(); }
    int totalBuses()     { return BusWayDB.getInstance().getAllBuses().size(); }
    int totalRoutes()    { return BusWayDB.getInstance().getAllRoutes().size(); }
    int totalSchedules() { return BusWayDB.getInstance().getAllSchedules().size(); }

    int totalBookings() { return BusWayDB.getInstance().getAllBookings().size(); }

    int confirmedBookings() {
        int c = 0;
        for (Booking b : BusWayDB.getInstance().getAllBookings())
            if (b.getStatus() == Booking.BookingStatus.CONFIRMED) c++;
        return c;
    }

    int cancelledBookings() {
        int c = 0;
        for (Booking b : BusWayDB.getInstance().getAllBookings())
            if (b.getStatus() == Booking.BookingStatus.CANCELLED) c++;
        return c;
    }

    double totalRevenue() {
        double sum = 0;
        for (Booking b : BusWayDB.getInstance().getAllBookings())
            if (b.getStatus() == Booking.BookingStatus.CONFIRMED) sum += b.getTotalFare();
        return sum;
    }

    // ── Route popularity ─────────────────────────────────────────────

    List<String[]> routePopularity() {
        Map<Long, Integer> map = new HashMap<>();
        for (Booking b : BusWayDB.getInstance().getAllBookings()) {
            if (b.getStatus() != Booking.BookingStatus.CONFIRMED) continue;
            Schedule sc = BusWayDB.getInstance().getScheduleById(b.getScheduleId());
            if (sc == null) continue;
            Long rId = sc.getRouteId();
            map.put(rId, map.getOrDefault(rId, 0) + b.getPassengerCount());
        }
        List<String[]> result = new ArrayList<>();
        for (Map.Entry<Long, Integer> e : map.entrySet()) {
            Route r = BusWayDB.getInstance().getRouteById(e.getKey());
            if (r != null) result.add(new String[]{ r.getDisplay(), String.valueOf(e.getValue()) });
        }
        result.sort((a, b) -> Integer.compare(Integer.parseInt(b[1]), Integer.parseInt(a[1])));
        return result;
    }

    // ── Bus utilisation ───────────────────────────────────────────────

    List<String[]> busUtilisation() {
        Map<Long, Integer> bookedMap = new HashMap<>();
        Map<Long, Integer> totalMap  = new HashMap<>();
        for (Schedule sc : BusWayDB.getInstance().getAllSchedules()) {
            Bus bus = BusWayDB.getInstance().getBusById(sc.getBusId());
            if (bus == null) continue;
            bookedMap.merge(sc.getBusId(), sc.getBookedSeats().size(), Integer::sum);
            totalMap.merge(sc.getBusId(), bus.getTotalSeats(), Integer::sum);
        }
        List<String[]> result = new ArrayList<>();
        for (Long busId : totalMap.keySet()) {
            Bus bus = BusWayDB.getInstance().getBusById(busId);
            if (bus == null) continue;
            int booked = bookedMap.getOrDefault(busId, 0);
            int total  = totalMap.get(busId);
            int pct    = total == 0 ? 0 : (booked * 100 / total);
            result.add(new String[]{ bus.getOperatorName() + " [" + bus.getBusNumber() + "]",
                    booked + "/" + total, pct + "%" });
        }
        result.sort((a, b) -> Integer.compare(
                Integer.parseInt(b[2].replace("%", "")),
                Integer.parseInt(a[2].replace("%", ""))));
        return result;
    }

    // ── Recent bookings ───────────────────────────────────────────────

    List<Booking> recentBookings(int limit) {
        List<Booking> all = BusWayDB.getInstance().getAllBookings();
        int from = Math.max(0, all.size() - limit);
        List<Booking> recent = new ArrayList<>(all.subList(from, all.size()));
        java.util.Collections.reverse(recent);
        return recent;
    }
}
