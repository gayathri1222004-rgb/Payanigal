package com.zsgs.busway.features.report;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.repository.BusWayDB;
import com.zsgs.busway.util.ConsoleInput;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;
import java.util.Scanner;

public class ReportView {

    private final ReportModel model;
    private final Scanner     scanner;

    public ReportView() {
        this.model   = new ReportModel();
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        while (true) {
            System.out.println();
            System.out.println("=== Reports ===");
            System.out.println("1. Summary Dashboard");
            System.out.println("2. Route Popularity");
            System.out.println("3. Bus Utilisation");
            System.out.println("4. Recent Bookings (last 10)");
            System.out.println("5. Back");
            System.out.print("Choose: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1": showSummary();      break;
                case "2": showRouteReport();  break;
                case "3": showBusReport();    break;
                case "4": showRecentBookings(); break;
                case "5": return;
                default: System.out.println("Invalid option.");
            }
        }
    }

    // ── Report screens ────────────────────────────────────────────────

    private void showSummary() {
        System.out.println();
        System.out.println("============================================");
        System.out.println("          BUSWAY SUMMARY DASHBOARD          ");
        System.out.println("============================================");
        System.out.printf("  %-28s %d%n",  "Total Registered Users:",    model.totalUsers());
        System.out.printf("  %-28s %d%n",  "Total Buses:",               model.totalBuses());
        System.out.printf("  %-28s %d%n",  "Total Routes:",              model.totalRoutes());
        System.out.printf("  %-28s %d%n",  "Total Schedules:",           model.totalSchedules());
        System.out.println("  " + "-".repeat(40));
        System.out.printf("  %-28s %d%n",  "Total Bookings:",            model.totalBookings());
        System.out.printf("  %-28s %d%n",  "  Confirmed:",               model.confirmedBookings());
        System.out.printf("  %-28s %d%n",  "  Cancelled:",               model.cancelledBookings());
        System.out.println("  " + "-".repeat(40));
        System.out.printf("  %-28s %s%n",  "Total Revenue:",             ParseHelper.formatFare(model.totalRevenue()));
        System.out.println("============================================");
    }

    private void showRouteReport() {
        System.out.println();
        System.out.println("=== Route Popularity (by passengers booked) ===");
        List<String[]> rows = model.routePopularity();
        if (rows.isEmpty()) { System.out.println("No booking data available."); return; }
        System.out.printf("%-5s %-30s %s%n", "#", "Route", "Passengers");
        System.out.println("-".repeat(50));
        for (int i = 0; i < rows.size(); i++) {
            System.out.printf("%-5d %-30s %s%n", i + 1, rows.get(i)[0], rows.get(i)[1]);
        }
    }

    private void showBusReport() {
        System.out.println();
        System.out.println("=== Bus Utilisation (across all schedules) ===");
        List<String[]> rows = model.busUtilisation();
        if (rows.isEmpty()) { System.out.println("No schedule data available."); return; }
        System.out.printf("%-5s %-35s %-14s %s%n", "#", "Bus", "Booked/Total", "Utilisation");
        System.out.println("-".repeat(65));
        for (int i = 0; i < rows.size(); i++) {
            System.out.printf("%-5d %-35s %-14s %s%n",
                    i + 1, trunc(rows.get(i)[0], 34), rows.get(i)[1], rows.get(i)[2]);
        }
    }

    private void showRecentBookings() {
        System.out.println();
        System.out.println("=== Recent Bookings (last 10) ===");
        List<Booking> bookings = model.recentBookings(10);
        if (bookings.isEmpty()) { System.out.println("No bookings yet."); return; }
        System.out.printf("%-14s %-22s %-12s %-10s %s%n",
                "PNR", "Route", "Date", "Status", "Fare");
        System.out.println("-".repeat(75));
        for (Booking b : bookings) {
            Schedule sc    = BusWayDB.getInstance().getScheduleById(b.getScheduleId());
            Route    route = sc != null ? BusWayDB.getInstance().getRouteById(sc.getRouteId()) : null;
            System.out.printf("%-14s %-22s %-12s %-10s %s%n",
                    b.getPnr(),
                    trunc(route != null ? route.getDisplay() : "-", 21),
                    sc != null ? ParseHelper.formatDate(sc.getDepartureTime()) : "-",
                    b.getStatus().name(),
                    ParseHelper.formatFare(b.getTotalFare()));
        }
    }

    private String trunc(String s, int max) {
        if (s == null) return "-";
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
