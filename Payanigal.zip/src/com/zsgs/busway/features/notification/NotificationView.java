package com.zsgs.busway.features.notification;

import com.zsgs.busway.data.dto.Notification;
import com.zsgs.busway.data.dto.User;
import com.zsgs.busway.util.ConsoleInput;
import com.zsgs.busway.util.ParseHelper;

import java.util.List;
import java.util.Scanner;

public class NotificationView {

    private final NotificationModel model;
    private final Scanner           scanner;

    public NotificationView(User currentUser) {
        this.model   = new NotificationModel(currentUser.getId());
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println();
        System.out.println("=== Notifications ===");

        long unread = model.getUnreadCount();
        if (unread > 0) System.out.println("You have " + unread + " unread notification(s).");

        List<Notification> list = model.getNotifications();
        if (list.isEmpty()) { System.out.println("No notifications."); return; }

        printNotifications(list);

        if (unread > 0) {
            System.out.print("Mark all as read? (Y/N): ");
            if (ParseHelper.isYes(scanner.nextLine())) {
                int count = model.markAllRead();
                System.out.println(count + " notification(s) marked as read.");
            }
        }
    }

    private void printNotifications(List<Notification> list) {
        System.out.println();
        for (int i = list.size() - 1; i >= 0; i--) {   // newest first
            Notification n = list.get(i);
            String read = Boolean.TRUE.equals(n.getIsRead()) ? "  " : "* ";
            System.out.println(read + "[" + ParseHelper.formatDateTime(n.getCreatedAt()) + "] "
                    + "(" + n.getType().name() + ") " + n.getMessage());
        }
        System.out.println();
    }
}
