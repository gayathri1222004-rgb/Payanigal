package com.zsgs.busway.features.notification;

import com.zsgs.busway.data.dto.Notification;
import com.zsgs.busway.data.repository.BusWayDB;

import java.util.List;

class NotificationModel {

    private final Long userId;

    NotificationModel(Long userId) {
        this.userId = userId;
    }

    List<Notification> getNotifications() {
        return BusWayDB.getInstance().getNotificationsForUser(userId);
    }

    int markAllRead() {
        return BusWayDB.getInstance().markAllNotificationsRead(userId);
    }

    long getUnreadCount() {
        return BusWayDB.getInstance().getUnreadNotificationCount(userId);
    }
}
