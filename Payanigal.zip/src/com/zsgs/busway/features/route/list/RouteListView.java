package com.zsgs.busway.features.route.list;

import com.zsgs.busway.data.dto.Route;

import java.util.List;

public class RouteListView {

    private final RouteListModel model;

    public RouteListView() {
        this.model = new RouteListModel();
    }

    public void init() {
        System.out.println();
        System.out.println("=== All Routes ===");
        List<Route> routes = model.getAllRoutes();
        if (routes.isEmpty()) { System.out.println("No routes added yet."); return; }

        System.out.printf("%-5s %-20s %-20s %s%n", "ID", "Origin", "Destination", "Distance (km)");
        System.out.println("-".repeat(55));
        for (Route r : routes) {
            System.out.printf("%-5d %-20s %-20s %d km%n",
                    r.getId(), r.getOrigin(), r.getDestination(), r.getDistanceKm());
        }
        System.out.println("Total: " + routes.size() + " routes");
    }
}
