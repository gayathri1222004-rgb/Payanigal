package com.zsgs.busway.features.route.list;

import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.repository.BusWayDB;

import java.util.List;

class RouteListModel {
    List<Route> getAllRoutes() { return BusWayDB.getInstance().getAllRoutes(); }
}
