package com.zsgs.busway.data.dto;

import java.util.ArrayList;
import java.util.List;

public class Schedule {

    private Long           id;
    private Long           busId;
    private Long           routeId;
    private Long           departureTime;
    private Long           arrivalTime;
    private double         farePerSeat;
    private ScheduleStatus status;
    private List<Integer>  bookedSeats;   // seat numbers 1..totalSeats

    public enum ScheduleStatus { SCHEDULED, DEPARTED, COMPLETED, CANCELLED }

    public Schedule() {
        this.bookedSeats = new ArrayList<>();
    }

    public Long getId()                            { return id; }
    public void setId(Long id)                     { this.id = id; }

    public Long getBusId()                         { return busId; }
    public void setBusId(Long busId)               { this.busId = busId; }

    public Long getRouteId()                       { return routeId; }
    public void setRouteId(Long routeId)           { this.routeId = routeId; }

    public Long getDepartureTime()                 { return departureTime; }
    public void setDepartureTime(Long t)           { this.departureTime = t; }

    public Long getArrivalTime()                   { return arrivalTime; }
    public void setArrivalTime(Long t)             { this.arrivalTime = t; }

    public double getFarePerSeat()                 { return farePerSeat; }
    public void setFarePerSeat(double f)           { this.farePerSeat = f; }

    public ScheduleStatus getStatus()              { return status; }
    public void setStatus(ScheduleStatus s)        { this.status = s; }

    public List<Integer> getBookedSeats()          { return bookedSeats; }
    public void setBookedSeats(List<Integer> s)    { this.bookedSeats = s; }

    public int availableSeats(int totalSeats) {
        return totalSeats - bookedSeats.size();
    }

    public boolean isSeatAvailable(int seatNo) {
        return !bookedSeats.contains(seatNo);
    }
}
