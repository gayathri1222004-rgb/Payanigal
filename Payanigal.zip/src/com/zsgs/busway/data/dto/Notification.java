package com.zsgs.busway.data.dto;

public class Notification {

    private Long             id;
    private Long             userId;
    private Long             bookingId;
    private String           message;
    private NotificationType type;
    private Boolean          isRead;
    private Long             createdAt;

    public enum NotificationType { BOOKING_CONFIRMED, BOOKING_CANCELLED, SCHEDULE_CHANGE, GENERAL }

    public Notification() {
    }

    public Long getId()                                { return id; }
    public void setId(Long id)                         { this.id = id; }

    public Long getUserId()                            { return userId; }
    public void setUserId(Long userId)                 { this.userId = userId; }

    public Long getBookingId()                         { return bookingId; }
    public void setBookingId(Long bookingId)           { this.bookingId = bookingId; }

    public String getMessage()                         { return message; }
    public void setMessage(String message)             { this.message = message; }

    public NotificationType getType()                  { return type; }
    public void setType(NotificationType type)         { this.type = type; }

    public Boolean getIsRead()                         { return isRead; }
    public void setIsRead(Boolean isRead)              { this.isRead = isRead; }

    public Long getCreatedAt()                         { return createdAt; }
    public void setCreatedAt(Long createdAt)           { this.createdAt = createdAt; }
}
