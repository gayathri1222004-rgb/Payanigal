package com.zsgs.busway.data.repository;

import com.zsgs.busway.data.dto.Booking;
import com.zsgs.busway.data.dto.Bus;
import com.zsgs.busway.data.dto.Notification;
import com.zsgs.busway.data.dto.Route;
import com.zsgs.busway.data.dto.Schedule;
import com.zsgs.busway.data.dto.User;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Singleton in-memory database.
 * All lists are private; access only through the public API methods.
 * Mirrors the ThiranXDB pattern from the ThiranX work-management system.
 */
public class BusWayDB {

    /* ------------------------------------------------------------------ */
    /*  Singleton                                                           */
    /* ------------------------------------------------------------------ */

    private static BusWayDB instance = null;

    private BusWayDB() {
        seedData();
    }

    public static BusWayDB getInstance() {
        if (instance == null) {
            instance = new BusWayDB();
        }
        return instance;
    }

    /* ------------------------------------------------------------------ */
    /*  Storage                                                             */
    /* ------------------------------------------------------------------ */

    private final List<User>         users         = new ArrayList<>();
    private final List<Bus>          buses         = new ArrayList<>();
    private final List<Route>        routes        = new ArrayList<>();
    private final List<Schedule>     schedules     = new ArrayList<>();
    private final List<Booking>      bookings      = new ArrayList<>();
    private final List<Notification> notifications = new ArrayList<>();

    private long userPk         = 0L;
    private long busPk          = 0L;
    private long routePk        = 0L;
    private long schedulePk     = 0L;
    private long bookingPk      = 0L;
    private long notificationPk = 0L;

    /* ------------------------------------------------------------------ */
    /*  Seed                                                                */
    /* ------------------------------------------------------------------ */

    private void seedData() {
        // Admin account
        User admin = new User();
        admin.setName("Admin");
        admin.setEmail("admin@busway.com");
        admin.setPassword("Admin@123");
        admin.setMobileNo("9000000000");
        admin.setRole(User.Role.ADMIN);
        addUser(admin);

        // Buses
        Bus b1 = new Bus(); b1.setBusNumber("KA01AB1234"); b1.setOperatorName("VRL Travels");      b1.setBusType(Bus.BusType.AC_SLEEPER);     b1.setTotalSeats(40);
        Bus b2 = new Bus(); b2.setBusNumber("TN02CD5678"); b2.setOperatorName("SRS Travels");      b2.setBusType(Bus.BusType.AC_SEATER);      b2.setTotalSeats(50);
        Bus b3 = new Bus(); b3.setBusNumber("AP03EF9012"); b3.setOperatorName("Orange Travels");   b3.setBusType(Bus.BusType.NON_AC_SLEEPER); b3.setTotalSeats(36);
        Bus b4 = new Bus(); b4.setBusNumber("MH04GH3456"); b4.setOperatorName("Parveen Travels");  b4.setBusType(Bus.BusType.NON_AC_SEATER);  b4.setTotalSeats(54);
        Bus bus1 = addBus(b1);
        Bus bus2 = addBus(b2);
        Bus bus3 = addBus(b3);
        Bus bus4 = addBus(b4);

        // Routes
        Route r1 = new Route(); r1.setOrigin("Hyderabad");  r1.setDestination("Bangalore");   r1.setDistanceKm(570);
        Route r2 = new Route(); r2.setOrigin("Hyderabad");  r2.setDestination("Chennai");      r2.setDistanceKm(625);
        Route r3 = new Route(); r3.setOrigin("Bangalore");  r3.setDestination("Mumbai");       r3.setDistanceKm(980);
        Route r4 = new Route(); r4.setOrigin("Chennai");    r4.setDestination("Coimbatore");   r4.setDistanceKm(495);
        Route r5 = new Route(); r5.setOrigin("Mumbai");     r5.setDestination("Pune");         r5.setDistanceKm(150);
        Route r6 = new Route(); r6.setOrigin("Hyderabad");  r6.setDestination("Mumbai");       r6.setDistanceKm(710);
        Route route1 = addRoute(r1);
        Route route2 = addRoute(r2);
        Route route3 = addRoute(r3);
        Route route4 = addRoute(r4);
        Route route5 = addRoute(r5);
        Route route6 = addRoute(r6);

        // Schedules — depart tomorrow & day-after so they are always bookable
        long base = tomorrowMidnight();

        addSchedule(bus1.getId(), route1.getId(), base + hrs(18), base + hrs(28), 950.0);
        addSchedule(bus2.getId(), route1.getId(), base + hrs(22), base + hrs(33), 750.0);
        addSchedule(bus3.getId(), route2.getId(), base + hrs(7),  base + hrs(18), 580.0);
        addSchedule(bus4.getId(), route2.getId(), base + hrs(14), base + hrs(25), 420.0);
        addSchedule(bus1.getId(), route3.getId(), base + hrs(20), base + hrs(38), 1350.0);
        addSchedule(bus2.getId(), route4.getId(), base + hrs(8),  base + hrs(17), 620.0);
        addSchedule(bus3.getId(), route5.getId(), base + hrs(6),  base + hrs(9),  320.0);
        addSchedule(bus4.getId(), route6.getId(), base + hrs(19), base + hrs(33), 870.0);
    }

    private long tomorrowMidnight() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    private long hrs(int h) {
        return (long) h * 3600_000L;
    }

    private void addSchedule(Long busId, Long routeId, long dep, long arr, double fare) {
        Schedule sc = new Schedule();
        sc.setBusId(busId);
        sc.setRouteId(routeId);
        sc.setDepartureTime(dep);
        sc.setArrivalTime(arr);
        sc.setFarePerSeat(fare);
        sc.setStatus(Schedule.ScheduleStatus.SCHEDULED);
        addSchedule(sc);
    }

    /* ------------------------------------------------------------------ */
    /*  User CRUD                                                           */
    /* ------------------------------------------------------------------ */

    public User addUser(User user) {
        if (user == null || user.getEmail() == null || user.getEmail().trim().isEmpty()) return null;
        userPk++;
        user.setId(userPk);
        user.setUserId(String.format(Locale.ROOT, "USR%05d", userPk));
        if (user.getCreatedAt() == null) user.setCreatedAt(System.currentTimeMillis());
        if (user.getStatus()    == null) user.setStatus(User.Status.ACTIVE);
        if (user.getRole()      == null) user.setRole(User.Role.PASSENGER);
        users.add(user);
        return user;
    }

    public User getUserByEmail(String email) {
        if (email == null) return null;
        String key = email.trim().toLowerCase(Locale.ROOT);
        for (User u : users) {
            if (u.getEmail() != null && u.getEmail().trim().toLowerCase(Locale.ROOT).equals(key)) return u;
        }
        return null;
    }

    public User authenticate(String email, String password) {
        User u = getUserByEmail(email);
        if (u == null || password == null || !password.equals(u.getPassword())) return null;
        return u;
    }

    public User getUserById(Long id) {
        if (id == null) return null;
        for (User u : users) { if (id.equals(u.getId())) return u; }
        return null;
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    /* ------------------------------------------------------------------ */
    /*  Bus CRUD                                                            */
    /* ------------------------------------------------------------------ */

    public Bus addBus(Bus bus) {
        if (bus == null) return null;
        busPk++;
        bus.setId(busPk);
        if (bus.getStatus() == null) bus.setStatus(Bus.BusStatus.ACTIVE);
        buses.add(bus);
        return bus;
    }

    public Bus getBusById(Long id) {
        if (id == null) return null;
        for (Bus b : buses) { if (id.equals(b.getId())) return b; }
        return null;
    }

    public List<Bus> getAllBuses() {
        return new ArrayList<>(buses);
    }

    public List<Bus> getActiveBuses() {
        List<Bus> result = new ArrayList<>();
        for (Bus b : buses) { if (b.getStatus() == Bus.BusStatus.ACTIVE) result.add(b); }
        return result;
    }

    /* ------------------------------------------------------------------ */
    /*  Route CRUD                                                          */
    /* ------------------------------------------------------------------ */

    public Route addRoute(Route route) {
        if (route == null) return null;
        routePk++;
        route.setId(routePk);
        routes.add(route);
        return route;
    }

    public Route getRouteById(Long id) {
        if (id == null) return null;
        for (Route r : routes) { if (id.equals(r.getId())) return r; }
        return null;
    }

    public List<Route> getAllRoutes() {
        return new ArrayList<>(routes);
    }

    /** Returns all distinct city names across all routes. */
    public List<String> getAllCities() {
        List<String> cities = new ArrayList<>();
        for (Route r : routes) {
            if (!cities.contains(r.getOrigin()))      cities.add(r.getOrigin());
            if (!cities.contains(r.getDestination())) cities.add(r.getDestination());
        }
        java.util.Collections.sort(cities);
        return cities;
    }

    /* ------------------------------------------------------------------ */
    /*  Schedule CRUD                                                       */
    /* ------------------------------------------------------------------ */

    public Schedule addSchedule(Schedule schedule) {
        if (schedule == null) return null;
        schedulePk++;
        schedule.setId(schedulePk);
        if (schedule.getStatus() == null) schedule.setStatus(Schedule.ScheduleStatus.SCHEDULED);
        schedules.add(schedule);
        return schedule;
    }

    public Schedule getScheduleById(Long id) {
        if (id == null) return null;
        for (Schedule sc : schedules) { if (id.equals(sc.getId())) return sc; }
        return null;
    }

    public List<Schedule> getAllSchedules() {
        return new ArrayList<>(schedules);
    }

    /**
     * Returns schedules matching origin/destination on the given travel date
     * (epoch millis of any time within that day).
     */
    public List<Schedule> searchSchedules(String origin, String destination, long travelDateMillis) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(travelDateMillis);
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);      cal.set(Calendar.MILLISECOND, 0);
        long dayStart = cal.getTimeInMillis();
        long dayEnd   = dayStart + 86_400_000L - 1L;

        List<Schedule> result = new ArrayList<>();
        for (Schedule sc : schedules) {
            if (sc.getStatus() == Schedule.ScheduleStatus.CANCELLED) continue;
            if (sc.getDepartureTime() < dayStart || sc.getDepartureTime() > dayEnd) continue;
            Route r = getRouteById(sc.getRouteId());
            if (r == null) continue;
            if (!r.getOrigin().equalsIgnoreCase(origin)) continue;
            if (!r.getDestination().equalsIgnoreCase(destination)) continue;
            result.add(sc);
        }
        return result;
    }

    public boolean updateSchedule(Schedule schedule) {
        if (schedule == null || schedule.getId() == null) return false;
        for (int i = 0; i < schedules.size(); i++) {
            if (schedule.getId().equals(schedules.get(i).getId())) {
                schedules.set(i, schedule);
                return true;
            }
        }
        return false;
    }

    /* ------------------------------------------------------------------ */
    /*  Booking CRUD                                                        */
    /* ------------------------------------------------------------------ */

    private static final String PNR_PREFIX = "BW";

    public Booking addBooking(Booking booking) {
        if (booking == null || booking.getUserId() == null || booking.getScheduleId() == null) return null;
        bookingPk++;
        booking.setId(bookingPk);
        booking.setPnr(String.format(Locale.ROOT, "%s%08d", PNR_PREFIX, bookingPk));
        if (booking.getBookedAt() == null) booking.setBookedAt(System.currentTimeMillis());
        if (booking.getStatus()   == null) booking.setStatus(Booking.BookingStatus.CONFIRMED);

        // Reserve seats in the schedule
        Schedule sc = getScheduleById(booking.getScheduleId());
        if (sc != null && booking.getSeats() != null) {
            for (int seat : booking.getSeats()) {
                if (!sc.getBookedSeats().contains(seat)) sc.getBookedSeats().add(seat);
            }
        }
        bookings.add(booking);
        return booking;
    }

    public Booking getBookingById(Long id) {
        if (id == null) return null;
        for (Booking b : bookings) { if (id.equals(b.getId())) return b; }
        return null;
    }

    public Booking getBookingByPnr(String pnr) {
        if (pnr == null || pnr.trim().isEmpty()) return null;
        String key = pnr.trim().toUpperCase(Locale.ROOT);
        for (Booking b : bookings) { if (key.equals(b.getPnr())) return b; }
        return null;
    }

    public List<Booking> getBookingsByUser(Long userId) {
        List<Booking> result = new ArrayList<>();
        if (userId == null) return result;
        for (Booking b : bookings) { if (userId.equals(b.getUserId())) result.add(b); }
        return result;
    }

    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookings);
    }

    public boolean cancelBooking(Long bookingId) {
        Booking b = getBookingById(bookingId);
        if (b == null || b.getStatus() == Booking.BookingStatus.CANCELLED) return false;
        b.setStatus(Booking.BookingStatus.CANCELLED);
        b.setCancelledAt(System.currentTimeMillis());

        // Free seats in schedule
        Schedule sc = getScheduleById(b.getScheduleId());
        if (sc != null && b.getSeats() != null) {
            sc.getBookedSeats().removeAll(b.getSeats());
        }
        return true;
    }

    /* ------------------------------------------------------------------ */
    /*  Notification CRUD                                                   */
    /* ------------------------------------------------------------------ */

    public Notification addNotification(Notification notification) {
        if (notification == null || notification.getUserId() == null) return null;
        notificationPk++;
        notification.setId(notificationPk);
        if (notification.getCreatedAt() == null) notification.setCreatedAt(System.currentTimeMillis());
        if (notification.getIsRead()    == null) notification.setIsRead(Boolean.FALSE);
        notifications.add(notification);
        return notification;
    }

    public List<Notification> getNotificationsForUser(Long userId) {
        List<Notification> result = new ArrayList<>();
        if (userId == null) return result;
        for (Notification n : notifications) { if (userId.equals(n.getUserId())) result.add(n); }
        return result;
    }

    public int markAllNotificationsRead(Long userId) {
        if (userId == null) return 0;
        int count = 0;
        for (Notification n : notifications) {
            if (userId.equals(n.getUserId()) && !Boolean.TRUE.equals(n.getIsRead())) {
                n.setIsRead(Boolean.TRUE);
                count++;
            }
        }
        return count;
    }

    public long getUnreadNotificationCount(Long userId) {
        if (userId == null) return 0;
        long count = 0;
        for (Notification n : notifications) {
            if (userId.equals(n.getUserId()) && !Boolean.TRUE.equals(n.getIsRead())) count++;
        }
        return count;
    }
}
